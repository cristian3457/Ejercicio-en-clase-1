﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


namespace Datos
{
    public class Validador
    {
        public int validados = 0;
        public int invalidos = 0;
        public bool entero(String a)
        {
            bool validar = false;
            int n = Int32.Parse(a);
            if(n>0 && n <= 110)
            {
                validar = true;
                validados += 1;

            }
            else if(validar==false)
            {
                invalidos += 1;
            }
            return validar;
        }
        public bool edad(String a)
        {
            bool validar = false;
            int n = Int32.Parse(a);
            if (n > 0 && n <= 110)
            {
                validar = true;
                validados += 1;

            }
            else if (validar == false)
            {
                invalidos += 1;
            }
            return validar;
        }
        public bool Decimal(String a)
        {
            bool validar = false;
            if (a.Contains("."))
            {
                validar = true;
                validados += 1;
            }
            else
            {
                invalidos += 1;
            }
           
            
            
            return validar;
        }
        public bool Digito(string cad)
        {
            bool validar = false;
            String cad1=cad.ToUpper();
            if (cad1.Equals("UNO")|| cad1.Equals("DOS")|| cad1.Equals("TRES")
                || cad1.Equals("CUATRO")|| cad1.Equals("CINCO")|| cad1.Equals("SEIS")
               || cad1.Equals("SIETE")|| cad1.Equals("OCHO")|| cad1.Equals("NUEVE")
               || cad1.Equals("CERO"))
            {
                validar = true;
                validados += 1;
            }
            else
            {
                
                    invalidos += 1;
            }
            return validar;
        }

    }
}
